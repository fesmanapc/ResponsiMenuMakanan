package com.demotxt.myapp.recyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Book> lstBook ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lstBook = new ArrayList<>();
        boolean add = lstBook.add(new Book("Nasi Uduk", "Categorie Makanan", "Nasi uduk atau dalam bahasa Belanda Rijst vermengd met onrust van de liefde atau disingkat Jaloerse rijst adalah nama makanan yang terbuat dari bahan dasar nasi putih yang diaron dan dikukus dengan santan, serta dibumbui dengan pala, kayu manis, jahe, daun serai dan merica", R.drawable.nasiuduk));
        lstBook.add(new Book("Sego Gandul","Categorie Makanan","Masakan khas dari Pati jawa Tengah",R.drawable.segogandul));
        lstBook.add(new Book("Fanta","Categorie Makanan","Fanta Kaleng",R.drawable.fanta));
        lstBook.add(new Book("Nasi","Categorie Makanan","Nasi Dengan Olahan Khas Hokben",R.drawable.themartian));
        lstBook.add(new Book("Nasi Pecel","Categorie Makanan","Pecel atau pecal merupakan makanan yang dikombinasikan dengan bumbu sambal kacang sebagai bahan utamanya dan dicampur dengan aneka jenis sayuran. Makanan ini populer terutama di wilayah DI Yogyakarta, Jawa Tengah, dan Jawa Timur.",R.drawable.nasipecel));
        lstBook.add(new Book("Super Supreme","Categorie Makanan","Daging ayam dan sapi asap, daging sapi cincang, burger sapi, jamur, paprika merah dan paprika hijau",R.drawable.pizza));
        lstBook.add(new Book("Meatballs Beef Mushroom Rice","Categorie Makanan","Nasi dengan bola daging sapi lembut disiram saus daging sapi cincang dan jamur",R.drawable.meat));
        lstBook.add(new Book("Garlic Bread","Categorie Makanan","Roti Panggang dengan bumbu bawang putih",R.drawable.garlic));
        lstBook.add(new Book("Fresh Salad / Buah","Categorie Makanan","Pilih sendiri sayuran segar setiap hari dan tentukan saus pilihanmu sebagai pendampingnya di Salad Bar.",R.drawable.salad));


        RecyclerView myrv = (RecyclerView) findViewById(R.id.recyclerview_id);
        RecyclerViewAdapter myAdapter = new RecyclerViewAdapter(this,lstBook);
        myrv.setLayoutManager(new GridLayoutManager(this,3));
        myrv.setAdapter(myAdapter);


    }
}
